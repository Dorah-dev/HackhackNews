using System;

namespace hackhacknews
{
    public class Hacknews
    {

        public string Title { get; set; }

        public string By { get; set; }

        public string Url { get; set; }
    }
}
