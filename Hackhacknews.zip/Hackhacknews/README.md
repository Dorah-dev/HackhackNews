# Read me first


## Built with

* Dotnet Core v3.1
* Angular v8.2
* Angular Material




