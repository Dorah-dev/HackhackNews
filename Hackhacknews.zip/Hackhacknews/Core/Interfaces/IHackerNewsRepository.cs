
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;

namespace hackhacknews.Core.Interfaces
{
    public interface IHackNewsRepository
    {
        Task<HttpResponseMessage> BestStoriesAsync();
        Task<HttpResponseMessage> GetStoryByIdAsync(int id);

    }
}