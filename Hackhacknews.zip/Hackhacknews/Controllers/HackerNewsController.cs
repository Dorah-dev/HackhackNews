using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;
using hackhacknews.Core.Interfaces;

namespace hackhacknews.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HackNewsController : ControllerBase
    {
        private IMemoryCache _cache;

        private readonly IHackNewsRepository _repo;

        public HackNewsController(IMemoryCache cache, IHackNewsRepository repository)
        {
            this._cache = cache;
            this._repo = repository;
        }

        public async Task<List<HackNewsStory>> Index(string searchTerm)
        {
            List<HackNewsStory> stories = new List<HackNewsStory>();

            var response = await _repo.BestStoriesAsync();
            if (response.IsSuccessStatusCode)
            {
                var storiesResponse = response.Content.ReadAsStringAsync().Result;
                var bestIds = JsonConvert.DeserializeObject<List<int>>(storiesResponse);

                var tasks = bestIds.Select(GetStoryAsync);
                stories = (await Task.WhenAll(tasks)).ToList();

                if (!String.IsNullOrEmpty(searchTerm))
                {
                    var search = searchTerm.ToLower();
                    stories = stories.Where(s =>
                                       s.Title.ToLower().IndexOf(search) > -1 || s.By.ToLower().IndexOf(search) > -1)
                                       .ToList();
                }
            }
            return stories;
        }

        private async Task<HackNewsStory> GetStoryAsync(int storyId)
        {
            return await _cache.GetOrCreateAsync<HackNewsStory>(storyId,
                async cacheEntry =>
                {
                    HackNewsStory story = new HackNewsStory();

                    var response = await _repo.GetStoryByIdAsync(storyId);
                    if (response.IsSuccessStatusCode)
                    {
                        var storyResponse = response.Content.ReadAsStringAsync().Result;
                        story = JsonConvert.DeserializeObject<HackNewsStory>(storyResponse);
                    }

                    return story;
                });
        }
    }
}
